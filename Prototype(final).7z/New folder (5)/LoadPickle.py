from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd 
import pickle
from sklearn.naive_bayes import MultinomialNB

#Read the merged data that was run in the jupyter file which involves machine leanring
df = pd.read_csv("SavedMergeddata.csv")

#The field from the csv file above
df_data = df[['Date','StringTransactionValue','Gender','Industry','check1']]
df_data['StrTransactionValue'] = df_data['StringTransactionValue'].astype(str)

# Features and Labels
df_data['Combine1'] = df_data[['Date','StrTransactionValue','Gender','Industry']].agg(' '.join,axis=1)

#df_x and df_y use for comparison of data in the bottom part of the code and also 1 to 1 ratio
df_x = df_data['Combine1']
df_y = df_data['check1']

# Extract Feature With CountVectorizer
corpus = df_x
cv = CountVectorizer() #convert comments into vectors
X = cv.fit_transform(corpus) # Fit the Data

#import the function from sklearn
from sklearn.model_selection import train_test_split
#jupyter change, here also change
X_train, X_test, y_train, y_test = train_test_split(X, df_y, test_size=0.25, train_size=0.33, random_state=15)

#load the pickle file in the varibale ytb_model. RB stands for read binary / Read binary file type
ytb_model = open("SavedPickle.pkl","rb")

clf.fit(X_train,y_train)

##comment = ["03/08/2018,1500,M,20,Technology"]
##for loop, loop into an array and export into csv file. ##13/08/2020,1500,M,20,Technology + repetitive
df1 = pd.read_csv("TestingData.csv") #change the mockdata to your csv file
#store the data from the csv file in to an array
frames = [df1]
#joining all the column of data from (frames) array
df_merged = pd.concat(frames)
#Change the Transaction Value to type string
df_merged['StringTransactionValue'] = df_merged['Transaction_Value'].astype(str)
#Change the age value to type string
df_merged['StringAge'] = df_merged['Age'].astype(str)
#df1_merged_data stored the labelling of the data from the csv file
df1_merged_data = df_merged[["Date","StringTransactionValue","Gender","StringAge","Industry"]].agg(','.join,axis=1)

#Use shape function to know the exact number of rows in the csv file and pass it as a value to the rows variable 
rows = df1_merged_data.shape[0]
#convert the float value to int
rows = int(rows)

#check the amount of rows of data
print(rows)
#check the output of the data after running the pickle file

#labelling the data repetitive or onetime with a for loop. 
for x in range (0, rows):
    comment = [df1_merged_data[x]]
    vect = cv.transform(comment).toarray()
    clf.predict(vect)
    
    if clf.predict(vect) == 1:
        df1_merged_data[x] = "Repetitive"
    else:
        df1_merged_data[x] = "OneTime"

#df_x1 till df_x5 stored the information 
df_x1 = df_merged[['Date']]
df_x2 = df_merged[['StringTransactionValue']]
df_x3 = df_merged[['Gender']]
df_x4 = df_merged[['Industry']]
df_x5 = df_merged[['Transaction_Type']]
df_data["Check"] = df1_merged_data
#df_y contains the labelling of data if it's repititve or one time.
df_y = df_data["Check"]

#dfdata contains the merged  from the learning process in the code segment above.
dfdata =  pd.concat([df_x1,df_x2,df_x3,df_x4,df_x5,df_y],ignore_index=False, sort=False,axis=1, join="inner")
print(dfdata)
#Writes the data to a csv file
dfdata.to_csv("Result.csv")