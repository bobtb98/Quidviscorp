from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd 
import pickle
from sklearn.naive_bayes import MultinomialNB


df = pd.read_csv("SavedMergeddata.csv")
df_data = df[["0","1"]]
# Features and Labels
df_x = df_data['0']
df_y = df_data['1']
# Extract Feature With CountVectorizer
corpus = df_x
cv = CountVectorizer() #convert comments into vectors
X = cv.fit_transform(corpus) # Fit the Data


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, df_y, test_size=0.50, train_size=0.25, random_state=2)
ytb_model = open("SavedPickle.pkl","rb")

#load the model
clf = pickle.load(ytb_model)
clf.fit(X_train,y_train)


##comment = ["03/08/2018,1500,M,20,Technology"]
##for loop, loop into an array and export into csv file. ##13/08/2020,1500,M,20,Technology + repetitive
df1 = pd.read_csv("Mock.csv")
frames = [df1]
df_merged = pd.concat(frames)
df_merged['StringTransactionValue'] = df_merged['Transaction_Value'].astype(str);
df_merged['StringAge'] = df_merged['Age'].astype(str);
df1_merged_data = df_merged[["Date","StringTransactionValue","Gender","StringAge","Industry"]].agg(','.join,axis=1)
df2_merged_data = df_merged[["Date","StringTransactionValue","Gender","StringAge","Industry"]].agg(','.join,axis=1)

rows = df1_merged_data.shape[0]
rows = int(rows)

for x in range (0, rows):
    comment = [df1_merged_data[x]]
    vect = cv.transform(comment).toarray()
    clf.predict(vect)
    
    if clf.predict(vect) == 1:
        df1_merged_data[x] = "Repetitive"
    else:
        df1_merged_data[x] = "OneTime"

df_x = df2_merged_data
df_y = df1_merged_data

frames = [df_x,df_y]
dfdata = pd.concat(frames,ignore_index=True,axis=1)
#output the restult to csv
dfdata.to_csv("Result.csv")