from flask import Flask, request, jsonify
from flask_restful import Resource, Api
import pandas as pd
import json

app= Flask(__name__)
api = Api(app)

data = 'Result.csv'


#debug
app.config['DEBUG'] = True

class Item(Resource):
    def post(self):
        df = pd.read_csv (data)
        df = df.to_json(orient="records")
        json.loads(df)
        return df

api.add_resource(Item,'/') 

app.run()
    

 

