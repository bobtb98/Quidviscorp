from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd 
import pickle
from sklearn.naive_bayes import MultinomialNB


df= pd.read_csv("SavedMergeddata.csv")
df_data = df[["0","1"]]
# Features and Labels
df_x = df_data['0']
df_y = df_data['1']
# Extract Feature With CountVectorizer
corpus = df_x
cv = CountVectorizer() #convert comments into vectors
X = cv.fit_transform(corpus) # Fit the Data


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, df_y, test_size=0.50, train_size=0.25, random_state=2)
ytb_model = open("SavedPickle.pkl","rb")

clf = pickle.load(ytb_model)

clf.fit(X_train,y_train)
clf.predict(X_test)

comment = ["13/08/2020,1500,M,20,Technology"]
vect = cv.transform(comment).toarray()

clf.predict(vect)

if clf.predict(vect) == 1:
    print("Repetitive")
else:
    print("OneTime")